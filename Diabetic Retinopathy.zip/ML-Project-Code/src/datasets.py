import numpy as np
import copy
import torch
import matplotlib.image as mpimg
import urllib.request
import zipfile
import os
import pandas as pd
from torchvision import datasets, transforms
from sampling import dist_datasets_iid, dist_datasets_noniid, get_sub_dataset
from options import args_parser
from torch.utils.data import Dataset, TensorDataset
import gdown

class DRDataset(Dataset):
    def __init__(self, data_label, data_dir, transform):
        super().__init__()
        self.data_label = data_label
        self.data_dir = data_dir
        self.transform = transform

    def __len__(self):
        return len(self.data_label)

    def __getitem__(self, index):
        if os.path.exists(self.data_dir+self.data_label.image[index] + '.png') == True:
            img_name = self.data_label.image[index] + '.png'
            
        elif os.path.exists(self.data_dir+self.data_label.image[index] + '.jpg') == True:
            img_name = self.data_label.image[index] + '.jpg'
        
        else:
            img_name = self.data_label.image[index] + '.jpeg'

        label = self.data_label.label[index]
        img_path = os.path.join(self.data_dir, img_name)
        image = mpimg.imread(img_path)
        image = (image + 1) * 127.5
        image = image.astype(np.uint8)
        image = self.transform(image)
        return image, label


def get_dataset(args):

    if args.dataset == 'cifar10' or args.dataset == 'cifar100':
        data_dir = '../data/cifar/'
        apply_transform = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
        
        if args.dataset == 'cifar10':
            train_dataset = datasets.CIFAR10(data_dir, train=True, download=True,
                                       transform=apply_transform)        
            test_dataset = datasets.CIFAR10(data_dir, train=False, download=True,
                                      transform=apply_transform)
        elif args.dataset == 'cifar100':
            train_dataset = datasets.CIFAR100(data_dir, train=True, download=True,
                                       transform=apply_transform)
            test_dataset = datasets.CIFAR100(data_dir, train=False, download=True,
                                      transform=apply_transform)    

    elif args.dataset == 'mnist' or args.dataset =='fmnist':
        if args.dataset == 'mnist':
            apply_transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))])

            data_dir = '../data/mnist/'
            train_dataset = datasets.MNIST(data_dir, train=True, download=True,
                                       transform=apply_transform)
            test_dataset = datasets.MNIST(data_dir, train=False, download=True,
                                      transform=apply_transform)

        else:
            apply_transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))])

            data_dir = '../data/fmnist/'
            train_dataset = datasets.FashionMNIST(data_dir, train=True, download=True,
                                       transform=apply_transform)
            test_dataset = datasets.FashionMNIST(data_dir, train=False, download=True,
                                      transform=apply_transform)
    
    elif args.dataset == 'dr':

        if args.dr_from_np == 1:
            if args.sub_dataset_size > 0:
                train_npy1 = args.train_images_npy + str(int(args.sub_dataset_size * 0.8)) + ".npy"
                train_npy2 = args.train_labels_npy + str(int(args.sub_dataset_size * 0.8)) + ".npy"

                test_npy1 = args.test_images_npy + str(int(args.sub_dataset_size * 0.2)) + ".npy"
                test_npy2 = args.test_labels_npy + str(int(args.sub_dataset_size * 0.2)) + ".npy"
            else:
                train_npy1 = args.train_images_npy + "all.npy"
                train_npy2 = args.train_labels_npy + "all.npy"

                test_npy1 = args.test_images_npy + "all.npy"
                test_npy2 = args.test_labels_npy + "all.npy"

            _x = torch.Tensor(np.load(args.parent_dir + train_npy1))
            _y = torch.Tensor(np.load(args.parent_dir + train_npy2)).long()
            train_dataset = TensorDataset(_x,_y)
            _x = torch.Tensor(np.load(args.parent_dir + test_npy1))
            _y = torch.Tensor(np.load(args.parent_dir + test_npy2)).long()
            test_dataset = TensorDataset(_x,_y)            
        
        else:
            # data_dir = '../data/diabetic_retinopathy/'
            # if not os.path.exists(data_dir):               
            #     os.makedirs(data_dir)
            
            # #download ZIP, unzip it, delete zip file
            # dataset_url = "https://drive.google.com/uc?id=1G-4UhPKiQY3NxQtZiWuOkdocDTW6Bw0u"
            # zip_path = data_dir + 'images.zip'
            # gdown.download(dataset_url, zip_path, quiet=False)
            # print("Extracting...!")
        
            # with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            #     zip_ref.extractall(data_dir)
            # print("Extracted!")
            # os.remove(zip_path)

            # #download train and test dataframes
            # test_csv_link = 'https://drive.google.com/uc?id=1dmeYLURzEvx962th4lAxaVN3r6nlhTjS'
            # train_csv_link = 'https://drive.google.com/uc?id=1SMb9CRHjB6UH2WnTZDFVSgpA6_nh75qN'

            # data_dir = 'D:\\DATASET\\\Dataset-1\\'
            # data_dir = args.data_dir
            train_csv_path =  args.parent_dir + args.train_csv
            test_csv_path = args.parent_dir + args.test_csv
            # train_csv_path = data_dir + 'train.csv'
            # urllib.request.urlretrieve(train_csv_link, train_csv_path)
            # urllib.request.urlretrieve(test_csv_link, test_csv_path)
            # df = pd.read_csv(csv_path)
            # sz = df.shape[0]
            # n = int(sz*0.7)
            # df_train = df.iloc[:n, :]
            # df_test = df.iloc[n:sz, :]
            df_train = pd.read_csv(train_csv_path)
            df_test = pd.read_csv(test_csv_path)

            #create train and test datasets
            apply_transform = transforms.Compose([transforms.ToPILImage(mode='RGB'),
                                    transforms.RandomHorizontalFlip(),
                                    transforms.Resize(256),
                                    transforms.CenterCrop(224),
                                    # transforms.CenterCrop(229),
                                    transforms.ToTensor(),
                                        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

            if args.data_set == 1:
                image_directory = args.data_dir_1
            else:
                image_directory = args.data_dir_2

            train_dataset = DRDataset(data_label = df_train, data_dir = image_directory,
                                        transform = apply_transform)
            # image_test_dir = data_dir + 'test_images\\'
            test_dataset = DRDataset(data_label = df_test, data_dir = image_directory,
                                        transform = apply_transform)

    print("Training Dataset Size: ", len(train_dataset))
    if args.dr_from_np == 0 and args.sub_dataset_size > 0:
        train_dataset = get_sub_dataset(train_dataset, args.sub_dataset_size)
        print("Sub Training Dataset Size: ", len(train_dataset))

        print("Test Data Size: ", len(test_dataset))
        test_dataset = get_sub_dataset(test_dataset, int(args.sub_dataset_size * 0.3))
        print("Sub Test Data Size: ", len(test_dataset))

        # rnd_indices = np.random.RandomState(seed=0).permutation(len(train_dataset.data))        
        # train_dataset.data = train_dataset.data[rnd_indices]
        # if torch.is_tensor(train_dataset.targets):
        #     train_dataset.targets = train_dataset.targets[rnd_indices]    
        # else:
        #     train_dataset.targets = torch.tensor(train_dataset.targets)[rnd_indices]
        # train_dataset.data = train_dataset.data[:args.sub_dataset_size]
        # train_dataset.targets = train_dataset.targets[:args.sub_dataset_size]
        # print("\nThe chosen sub dataset has the following shape:")
        # print(train_dataset.data.shape, train_dataset.targets.shape,"\n")        

    if args.iid:                   
        user_groups, users_test_data = dist_datasets_iid(train_dataset, args.num_users, args.rounds)         
    else:
        user_groups = dist_datasets_noniid(train_dataset, args.num_users,
                                            num_shards=args.num_shards,                                                
                                            unequal=args.unequal)    
    
    return train_dataset, test_dataset, user_groups, users_test_data

# ## For test
# if __name__ == '__main__':
#     args = args_parser()
#     train_dataset, test_dataset, user_groups = get_dataset(args)
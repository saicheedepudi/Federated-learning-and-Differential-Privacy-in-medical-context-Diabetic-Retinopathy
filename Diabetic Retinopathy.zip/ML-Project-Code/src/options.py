import argparse

def args_parser():
    
    parser = argparse.ArgumentParser()

    ## etc.
    parser.add_argument('--virtual_batch_size', type=int, default=1, 
                        help='DP VIRTUAL_BATCH_SIZE')

    ## Optimizer
    parser.add_argument('--optimizer', type=str, default='sgd', help="type \
                        of optimizer")

    parser.add_argument('--lr', type=float, default=.002,
                        help='learning rate')

    parser.add_argument('--momentum', type=float, default=0.9,
                        help='SGD momentum (default: 0.0)')


    # model arguments
    parser.add_argument('--model', type=str, default='cnn', help='model name')

    parser.add_argument('--activation', type=str, default="relu",
                        help='SGD momentum (default: 0.0)')

    # other arguments
    parser.add_argument('--dataset', type=str, default='dr', help="name \
                        of dataset")

    parser.add_argument('--unequal', type=int, default=0,
                        help='whether to use unequal data splits for  \
                        non-i.i.d setting (use 0 for equal splits)')
                        
                    
    parser.add_argument('--dr_from_np', type=float, default=0, help='for diabetic_retinopathy dataset')                    

    ## DP arguments
    parser.add_argument('--withDP', type=int, default=1, help='WithDP')
    parser.add_argument('--max_grad_norm', type=float, default= 2., help='DP MAX_GRAD_NORM')

    parser.add_argument('--sampling_prob', type=int, default=0.03425 , help='sampling_prob')
    parser.add_argument('--frac', type=float, default=1., help='the fraction of clients: C')

    # Can be changed the following values for model training

    # federated arguments (Notation for the arguments followed from paper)
    parser.add_argument('--local_bs', type=int, default=1, help="local batch size: B")
    parser.add_argument('--local_test_split', type=float, default=0., help='DP DELTA')  
    parser.add_argument('--iid', type=int, default=1, help='Default set to IID. Set to 0 for non-IID.')
    parser.add_argument('--num_shards', type=int, default=100, help='Its needed for non-IID.')
                        
    parser.add_argument('--sub_dataset_size', type=int, default=2000, help='To reduce original data to a smaller sized dataset. For experimental purposes.')
    parser.add_argument('--rounds', type=int, default=400, help="number of rounds of training")

    parser.add_argument('--num_users', type=int, default=50, help="number of users: K")
    parser.add_argument('--local_ep', type=int, default=100, help="the number of local epochs: E")
    
    parser.add_argument('--noise_multiplier', type=float, default=0.0, help='DP NOISE_MULTIPLIER')
    parser.add_argument('--delta', type=float, default=0.0 , help='DP DELTA')

    parser.add_argument('--model_type', type=str, default='Alexnet', 
                            help='Image classification model name[Resnet50, Alexnet, Vgg16, Squeezenet1.1, Densenet121, #InceptionV3, #googelnet]')
    parser.add_argument('--gpu', default="cuda:1", help="To use cuda, set \
                        to a specific GPU ID. Default set to use CPU.")
    parser.add_argument('--data_set', type=int, default=2, help="Select Dataset which will be trained.")
    parser.add_argument('--data_dir_1', type=str, default="/home/siu856533724/dataset/resized/original/resized_train/", help="Directory where whole dataset is stored.")
    parser.add_argument('--data_dir_2', type=str, default="/home/siu856533724/dataset/aptos2019/images/", help="Directory where whole dataset is stored.")

    parser.add_argument('--train_csv', type=str, default="/home/siu856533724/code/train_labels_2.csv", help="The Label file for training dataset.")
    parser.add_argument('--test_csv', type=str, default="/home/siu856533724/code/test_labels_2.csv", help="The Label file for test dataset.")
    parser.add_argument('--exp_name', type=str, default="DPSGD", help="The name of current experiment for logging.")

    args = parser.parse_args([])
    return args

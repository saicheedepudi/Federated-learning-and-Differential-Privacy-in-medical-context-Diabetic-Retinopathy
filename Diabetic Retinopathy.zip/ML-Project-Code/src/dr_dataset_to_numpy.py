import os
import copy
import time
import pickle
import numpy as np
import torch
from options import args_parser
from datasets import get_dataset



if __name__ == '__main__':
    
    ############# Common ###################
    args = args_parser()    
    if args.gpu:
        torch.cuda.set_device(args.gpu)
    device = args.gpu if args.gpu else 'cpu'

    print("Data Size: ", args.sub_dataset_size)
    # load dataset and user groups
    train_dataset, test_dataset, user_groups = get_dataset(args)
    
    print("train_dataset size:", len(train_dataset))
    print("test_dataset size:", len(test_dataset))

    dir = "/home/siu856533724/code/data/"
    
    train_len = str(len(train_dataset))
    test_len = str(len(test_dataset))

    # print("data shape:", train_dataset[0][0].shape)
    print("----->Train")
    dr_images = []
    dr_labels = []
    for i in range(len(train_dataset)):        
        _image, _label = train_dataset[i]
        dr_images.append(_image.numpy())
        dr_labels.append(_label)
        print("  ", i, end="\r")
    print("")
    dr_images = np.array(dr_images)
    dr_labels = np.array(dr_labels)
    np.save(dir+"dr_train_images_"+train_len+".npy", dr_images)
    np.save(dir+"dr_train_labels_"+train_len+".npy", dr_labels)
    print("----->Test")
    dr_images = []
    dr_labels = []
    for i in range(len(test_dataset)):        
        _image, _label = test_dataset[i]
        dr_images.append(_image.numpy())
        dr_labels.append(_label)
        print("  ", i, end="\r")
    print("")
    dr_images = np.array(dr_images)
    dr_labels = np.array(dr_labels)
    np.save(dir+"dr_test_images_"+test_len+".npy", dr_images)
    np.save(dir+"dr_test_labels_"+test_len+".npy", dr_labels)

    print("Done!")